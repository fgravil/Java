
public class NotFoundException extends RuntimeException {

	
	
}
